# Sign In (session storage)

## File

* [`2-student-do-signin-no-persistence`](../02-signin-nopersistence/Unsolved/2-student-do-signin-no-persistence.html)

## Instructions

* Now reconfigure your app to use session storage instead! (You should be following along with your instructor for this one.)
