const HelloDiv = () => null;

export default HelloDiv;
