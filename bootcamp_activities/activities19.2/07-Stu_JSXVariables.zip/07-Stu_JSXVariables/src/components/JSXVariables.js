import React from "react";

const JSXVariables = () => (
  <div className="main-container">
    <div className="container">
      <div className="jumbotron">
        <h1>Hi! My name is (insert name here)</h1>
        <h2>My name has (insert number of letters in name here) letters</h2>
        <h2>I think React (insert thoughts about React here)</h2>
      </div>
    </div>
  </div>
);

export default JSXVariables;
