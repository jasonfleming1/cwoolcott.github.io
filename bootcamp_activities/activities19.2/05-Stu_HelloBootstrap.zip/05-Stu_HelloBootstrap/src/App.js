import React from "react";

const App = () => <p>Render Bootstrap components here</p>;

export default App;
